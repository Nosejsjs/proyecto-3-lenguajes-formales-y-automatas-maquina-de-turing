import tkinter as tk
from tkinter import ttk, messagebox
import time

class TuringMachine:
    """
     Aca es la logica de la máquina de ayan turing
    """
    def __init__(self):
        self.tape = []
        self.head_position = 0
        self.current_state = 'q0'
        self.transitions = {}
        self.accept_states = set()
        self.reject_states = set()
        self.blank_symbol = '_'
        

    def load_regex(self, regex_name):
        """Carga las  transiciones para una expresión regular  específica"""
        self.transitions = {}
        self.accept_states = set()
        self.reject_states = {'qReject'}
        
        if regex_name == "(a|b)*abb":
            # reconoce las cadenas que terminan en "abb"  
            self.transitions = {
                ('q0', 'a'): ('q1', 'a', 'R'),
                ('q0', 'b'): ('q0', 'b', 'R'),
                ('q1', 'a'): ('q1', 'a', 'R'),
                ('q1', 'b'): ('q2', 'b', 'R'),
                ('q2', 'a'): ('q1', 'a', 'R'),
                ('q2', 'b'): ('q3', 'b', 'R'),
                ('q3', '_'): ('qAccept', '_', 'N'),
                ('q0', '_'): ('qReject', '_', 'N'),
                ('q1', '_'): ('qReject', '_', 'N'),
                ('q2', '_'): ('qReject', '_', 'N'),
            }
            self.accept_states = {'qAccept'}
            
        elif regex_name == "0*1*":
            # Reconoce las cadenas de ceros seguidos de unos  
            self.transitions = {
                ('q0', '0'): ('q0', '0', 'R'),
                ('q0', '1'): ('q1', '1', 'R'),
                ('q0', '_'): ('qAccept', '_', 'N'),
                ('q1', '1'): ('q1', '1', 'R'),
                ('q1', '0'): ('qReject', '0', 'N'),
                ('q1', '_'): ('qAccept', '_', 'N'),
            }
            self.accept_states = {'qAccept'}
            
        elif regex_name == "(ab)*":
            # Reconoce las cadenas de "ab" asi varias veces
            self.transitions = {
                ('q0', 'a'): ('q1', 'a', 'R'),
                ('q0', '_'): ('qAccept', '_', 'N'),
                ('q1', 'b'): ('q0', 'b', 'R'),
                ('q1', 'a'): ('qReject', 'a', 'N'),
                ('q1', '_'): ('qReject', '_', 'N'),
                ('q0', 'b'): ('qReject', 'b', 'N'),
            }
            self.accept_states = {'qAccept'}
            
        elif regex_name == "1(01)*0":
            # Reconoce las cadenas que empiezan con 1, terminan en 0, y tienen "01" en el medio
            self.transitions = {
                ('q0', '1'): ('q1', '1', 'R'),
                ('q0', '0'): ('qReject', '0', 'N'),
                ('q0', '_'): ('qReject', '_', 'N'),
                ('q1', '0'): ('q2', '0', 'R'),
                ('q1', '_'): ('qReject', '_', 'N'),
                ('q2', '1'): ('q1', '1', 'R'),
                ('q2', '_'): ('qAccept', '_', 'N'),
                ('qAccept', '_'): ('qAccept', '_', 'N'),
                ('qAccept', '0'): ('qReject', '0', 'N'),
                ('qAccept', '1'): ('qReject', '1', 'N'),
            }
            self.accept_states = {'qAccept'}
            
        elif regex_name == "(a+b)*a(a+b)*":
            # Reconoce las cadenas  que contienen al menos una 'a' 
            self.transitions = {
                ('q0', 'a'): ('q1', 'a', 'R'),
                ('q0', 'b'): ('q0', 'b', 'R'),
                ('q0', '_'): ('qReject', '_', 'N'),
                ('q1', 'a'): ('q1', 'a', 'R'),
                ('q1', 'b'): ('q1', 'b', 'R'),
                ('q1', '_'): ('qAccept', '_', 'N'),
            }
            self.accept_states = {'qAccept'}
            
        elif regex_name == "a*b*":
            # Reconoce las cadenas de a's seguidas de b's  
            self.transitions = {
                ('q0', 'a'): ('q0', 'a', 'R'),
                ('q0', 'b'): ('q1', 'b', 'R'),
                ('q0', '_'): ('qAccept', '_', 'N'),
                ('q1', 'b'): ('q1', 'b', 'R'),
                ('q1', 'a'): ('qReject', 'a', 'N'),
                ('q1', '_'): ('qAccept', '_', 'N'),
            }
            self.accept_states = {'qAccept'}
            
        elif regex_name == "(aa)*":
            # Reconoce lass cadenas con número par de a's
            self.transitions = {
                ('q0', 'a'): ('q1', 'a', 'R'),
                ('q0', '_'): ('qAccept', '_', 'N'),
                ('q0', 'b'): ('qReject', 'b', 'N'),
                ('q1', 'a'): ('q0', 'a', 'R'),
                ('q1', '_'): ('qReject', '_', 'N'),
                ('q1', 'b'): ('qReject', 'b', 'N'),
            }
            self.accept_states = {'qAccept'}
            
        elif regex_name == "0*10*":
            # Reconoce las cadenas con exactamente un 1
            self.transitions = {
                ('q0', '0'): ('q0', '0', 'R'),
                ('q0', '1'): ('q1', '1', 'R'),
                ('q0', '_'): ('qReject', '_', 'N'),
                ('q1', '0'): ('q1', '0', 'R'),
                ('q1', '1'): ('qReject', '1', 'N'),
                ('q1', '_'): ('qAccept', '_', 'N'),
            }
            self.accept_states = {'qAccept'}
            
        elif regex_name == "(ba)*b":
            # Reconoce las cadenas de "ba" repetido terminando en b 
            self.transitions = {
                ('q0', 'b'): ('q1', 'b', 'R'),
                ('q0', 'a'): ('qReject', 'a', 'N'),
                ('q0', '_'): ('qReject', '_', 'N'),
                ('q1', 'a'): ('q0', 'a', 'R'),
                ('q1', 'b'): ('qReject', 'b', 'N'),
                ('q1', '_'): ('qAccept', '_', 'N'),
            }
            self.accept_states = {'qAccept'}
            
        elif regex_name == "1*01*":
            # Reconoce las cadenas con exactamente un  0 
            self.transitions = {
                ('q0', '1'): ('q0', '1', 'R'),
                ('q0', '0'): ('q1', '0', 'R'),
                ('q0', '_'): ('qReject', '_', 'N'),
                ('q1', '1'): ('q1', '1', 'R'),
                ('q1', '0'): ('qReject', '0', 'N'),
                ('q1', '_'): ('qAccept', '_', 'N'),
            }
            self.accept_states = {'qAccept'}
    
    def initialize(self, input_string, regex_name):
        """Inicializa la máquina con una cadena de entrada"""
        self.load_regex(regex_name)
        self.tape = list(input_string) if input_string else []
        self.tape.append(self.blank_symbol)
        self.head_position = 0
        self.current_state = 'q0'
        
    def step(self):
        """Ejecuta un solo paso de la máquina de Turing"""
        if self.current_state in self.accept_states or self.current_state in self.reject_states:
            return False
        
        while self.head_position >= len(self.tape):
            self.tape.append(self.blank_symbol)
        
        current_symbol = self.tape[self.head_position]
        key = (self.current_state, current_symbol)
        
        if key not in self.transitions:
            self.current_state = 'qReject'
            return False
        
        new_state, write_symbol, direction = self.transitions[key]
        
        self.tape[self.head_position] = write_symbol
        
        # Mover el cabezal
        if direction == 'R':
            self.head_position += 1
        elif direction == 'L':
            self.head_position = max(0, self.head_position - 1)
        
        # Cambiar de estado
        self.current_state = new_state
        
        return True
    
    def is_accepted(self):
        """Verifica si la cadena fue aceptada, todo nice"""
        return self.current_state in self.accept_states
    
    def is_rejected(self):
        """Verifica si la cadena fue rechazada, (uy no qué mal joven)"""
        return self.current_state in self.reject_states
    
    def is_finished(self):
        """Verifica si la máquina terminó de ejecturarse"""
        return self.current_state in self.accept_states or self.current_state in self.reject_states


class TuringSimulatorGUI:
    """
    Tdo lo gráfico
    """
    def __init__(self, root):
        self.root = root
        self.root.title("Simulador de Máquina de Turing \n Daniel del Cid 1009823") #no se ve pero para que se sepa jajksjka
        self.root.geometry("1000x700")
        self.root.configure(bg='#f0f0f0')
        
        self.tm = TuringMachine()
        self.is_running = False
        self.animation_speed = 500
        
        # Lista de expresiones regulares
        self.regex_list = [
            "(a|b)*abb",
            "0*1*",
            "(ab)*",
            "1(01)*0",
            "(a+b)*a(a+b)*",
            "a*b*",
            "(aa)*",
            "0*10*",
            "(ba)*b",
            "1*01*"
        ]

        # Alfabeto esperado por ER (para validar y avisar, pero ps no bloquea)
        self.expected_alphabet = {
            "(a|b)*abb": set("ab"),
            "0*1*": set("01"),
            "(ab)*": set("ab"),
            "1(01)*0": set("01"),
            "(a+b)*a(a+b)*": set("ab"),
            "a*b*": set("ab"),
            "(aa)*": set("ab"),
            "0*10*": set("01"),
            "(ba)*b": set("ab"),
            "1*01*": set("01"),
        }
        
        self.setup_ui()
        
    def setup_ui(self):
        """interfaz del usuario"""
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        title_label = tk.Label(main_frame, text="Simulador de Máquina de Turing\n Daniel del Cid 1009823", 
                               font=('Arial', 20, 'bold'), bg='#f0f0f0', fg='#2c3e50')
        title_label.pack(pady=10)
        
        input_frame = tk.LabelFrame(main_frame, text="Configuración", 
                                    font=('Arial', 12, 'bold'), bg='#f0f0f0', padx=10, pady=10)
        input_frame.pack(fill=tk.X, pady=5)
        
        regex_frame = tk.Frame(input_frame, bg='#f0f0f0')
        regex_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(regex_frame, text="Expresión Regular:", 
                font=('Arial', 10), bg='#f0f0f0').pack(side=tk.LEFT, padx=5)
        
        self.regex_var = tk.StringVar(value=self.regex_list[0])
        regex_combo = ttk.Combobox(regex_frame, textvariable=self.regex_var, 
                                   values=self.regex_list, state='readonly', width=30)
        regex_combo.pack(side=tk.LEFT, padx=5)
        
        string_frame = tk.Frame(input_frame, bg='#f0f0f0')
        string_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(string_frame, text="Cadena de Entrada:", 
                font=('Arial', 10), bg='#f0f0f0').pack(side=tk.LEFT, padx=5)
        
        self.input_entry = tk.Entry(string_frame, font=('Arial', 12), width=40)
        self.input_entry.pack(side=tk.LEFT, padx=5)
        
        # Botón de inicializar
        init_button = tk.Button(string_frame, text="Inicializar", 
                               command=self.initialize_machine,
                               bg='#3498db', fg='white', font=('Arial', 10, 'bold'),
                               padx=10, pady=5, cursor='hand2')
        init_button.pack(side=tk.LEFT, padx=5)
        
        control_frame = tk.LabelFrame(main_frame, text="Controles", 
                                     font=('Arial', 12, 'bold'), bg='#f0f0f0', padx=10, pady=10)
        control_frame.pack(fill=tk.X, pady=5)
        
        # Botones de control
        button_frame = tk.Frame(control_frame, bg='#f0f0f0')
        button_frame.pack()
        
        self.step_button = tk.Button(button_frame, text="Paso a Paso", 
                                     command=self.step_execution,
                                     bg="#caffe0", fg='white', font=('Arial', 10, 'bold'),
                                     padx=15, pady=5, cursor='hand2', state=tk.DISABLED)
        self.step_button.pack(side=tk.LEFT, padx=5)
        
        self.run_button = tk.Button(button_frame, text="Ejecutar Auto", 
                                    command=self.run_automatic,
                                    bg="#33ff00", fg='white', font=('Arial', 10, 'bold'),
                                    padx=15, pady=5, cursor='hand2', state=tk.DISABLED)
        self.run_button.pack(side=tk.LEFT, padx=5)
        
        self.stop_button = tk.Button(button_frame, text="Detener", 
                                     command=self.stop_execution,
                                     bg="#ff0000", fg='white', font=('Arial', 10, 'bold'),
                                     padx=15, pady=5, cursor='hand2', state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=5)
        
        self.reset_button = tk.Button(button_frame, text="Reiniciar", 
                                      command=self.reset_machine,
                                      bg="#ffe600", fg='white', font=('Arial', 10, 'bold'),
                                      padx=15, pady=5, cursor='hand2', state=tk.DISABLED)
        self.reset_button.pack(side=tk.LEFT, padx=5)
        
        # Control de velocidad
        speed_frame = tk.Frame(control_frame, bg='#f0f0f0')
        speed_frame.pack(pady=10)
        
        tk.Label(speed_frame, text="Velocidad:", 
                font=('Arial', 10), bg='#f0f0f0').pack(side=tk.LEFT, padx=5)
        
        self.speed_var = tk.IntVar(value=500)
        speed_scale = tk.Scale(speed_frame, from_=100, to=2000, orient=tk.HORIZONTAL,
                              variable=self.speed_var, command=self.update_speed,
                              bg='#f0f0f0', length=200)
        speed_scale.pack(side=tk.LEFT, padx=5)
        
        tk.Label(speed_frame, text="ms", 
                font=('Arial', 10), bg='#f0f0f0').pack(side=tk.LEFT)
        
        status_frame = tk.LabelFrame(main_frame, text="Estado Actual", 
                                    font=('Arial', 12, 'bold'), bg='#f0f0f0', padx=10, pady=10)
        status_frame.pack(fill=tk.X, pady=5)
        
        self.state_label = tk.Label(status_frame, text="Estado: -", 
                                    font=('Arial', 14, 'bold'), bg='#f0f0f0', fg='#2c3e50')
        self.state_label.pack(pady=5)
        
        self.position_label = tk.Label(status_frame, text="Posición del Cabezal: -", 
                                      font=('Arial', 11), bg='#f0f0f0', fg='#34495e')
        self.position_label.pack()
        
        self.result_label = tk.Label(status_frame, text="", 
                                     font=('Arial', 12, 'bold'), bg='#f0f0f0')
        self.result_label.pack(pady=5)
        
        tape_frame = tk.LabelFrame(main_frame, text="Cinta de la máquina de Turing", 
                                  font=('Arial', 12, 'bold'), bg='#f0f0f0', padx=10, pady=10)
        tape_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.canvas = tk.Canvas(tape_frame, bg='white', height=150)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        info_frame = tk.Frame(main_frame, bg='#f0f0f0')
        info_frame.pack(fill=tk.X, pady=5)
        
        info_text = "Instrucciones: Selecciona una expresión regular, ingresa una cadena y presiona Inicializar"
        tk.Label(info_frame, text=info_text, 
                font=('Arial', 9), bg='#f0f0f0', fg='#7f8c8d').pack()

    def update_speed(self, value):
        """Actualiza la velocidad de animación"""
        self.animation_speed = int(value)

    def _validate_input(self, regex_name, s):
        """Valida amistosamente el alfabeto esperado según la ER (muestra warning, no bloquea)."""
        allowed = self.expected_alphabet.get(regex_name, set("ab01"))
        invalid = [ch for ch in s if ch not in allowed]
        if invalid:
            messagebox.showwarning(
                "Símbolos no válidos",
                f"Se encontraron símbolos fuera del alfabeto esperado {sorted(allowed)}: {sorted(set(invalid))}\n"
                "La máquina intentará procesar, pero probablemente rechazará la cadena."
            )
        
    def initialize_machine(self):
        """Inicializa la máquina con los valores ingresados"""
        input_string = self.input_entry.get()
        regex_name = self.regex_var.get()

        # Permitir cadena vacía (ε). No mostramos warning ni bloqueamos.
        if input_string is None:
            input_string = ""

        # Validación amigable de alfabeto, pero continuar igual.
        self._validate_input(regex_name, input_string)
        
        self.tm.initialize(input_string, regex_name)
        self.is_running = False
        
        # Habilitar botones
        self.step_button.config(state=tk.NORMAL)
        self.run_button.config(state=tk.NORMAL)
        self.reset_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        
        # Limpiar resultado
        self.result_label.config(text="")
        
        # Actualizar visualización
        self.update_display()
        
        messagebox.showinfo("Todo joya", f"Máquina inicializada con la expresión: {regex_name}")
        
    def step_execution(self):
        """Ejecuta un solo paso de la máquina"""
        if self.tm.is_finished():
            self.show_result()
            return
        
        can_continue = self.tm.step()
        self.update_display()
        
        if not can_continue or self.tm.is_finished():
            self.show_result()
            
    def run_automatic(self):
        """Ejecuta la máquina automáticamente"""
        if self.is_running:
            return
        
        self.is_running = True
        self.step_button.config(state=tk.DISABLED)
        self.run_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        
        self.auto_step()
        
    def auto_step(self):
        """Ejecuta un paso automático con animación"""
        if not self.is_running:
            return
        
        if self.tm.is_finished():
            self.show_result()
            self.stop_execution()
            return
        
        can_continue = self.tm.step()
        self.update_display()
        
        if can_continue and not self.tm.is_finished():
            self.root.after(self.animation_speed, self.auto_step)
        else:
            self.show_result()
            self.stop_execution()
            
    def stop_execution(self):
        """Detiene la ejecución automática"""
        self.is_running = False
        self.step_button.config(state=tk.NORMAL)
        self.run_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        
    def reset_machine(self):
        """Reinicia la máquina con la misma configuración"""
        self.stop_execution()
        self.initialize_machine()
        
    def update_display(self):
        """Actualiza la visualización de la cinta y el estado"""
        # Actualiza etiquetas de estado
        self.state_label.config(text=f"Estado: {self.tm.current_state}")
        self.position_label.config(text=f"Posición del Cabezal: {self.tm.head_position}")
        
        # Dibuja la cinta
        self.draw_tape()
        
    def draw_tape(self):
        """Dibuja la cinta en el canvas"""
        self.canvas.delete("all")
        
        cell_width = 50
        cell_height = 50
        start_x = 50
        start_y = 50
        
        # Determina qué parte de la cinta mostrar
        visible_cells = 15
        start_index = max(0, self.tm.head_position - visible_cells // 2)
        end_index = min(len(self.tm.tape), start_index + visible_cells)
        
        if end_index - start_index < visible_cells:
            start_index = max(0, end_index - visible_cells)
        
        for i in range(start_index, end_index):
            x = start_x + (i - start_index) * cell_width
            
            if i == self.tm.head_position:
                fill_color = '#3498db'  
                text_color = 'white'
            else:
                fill_color = 'white'
                text_color = 'black'
            
            self.canvas.create_rectangle(x, start_y, x + cell_width, start_y + cell_height,
                                        fill=fill_color, outline='black', width=2)
            
            symbol = self.tm.tape[i] if i < len(self.tm.tape) else '_'
            self.canvas.create_text(x + cell_width/2, start_y + cell_height/2,
                                   text=symbol, font=('Arial', 16, 'bold'), fill=text_color)
            
            self.canvas.create_text(x + cell_width/2, start_y + cell_height + 15,
                                   text=str(i), font=('Arial', 9), fill='gray')
        
        # Dibujar indicador del cabezal
        if start_index <= self.tm.head_position < end_index:
            x = start_x + (self.tm.head_position - start_index) * cell_width
            # Triángulo apuntando hacia abajo
            points = [x + cell_width/2, start_y - 15,
                     x + cell_width/2 - 10, start_y - 5,
                     x + cell_width/2 + 10, start_y - 5]
            self.canvas.create_polygon(points, fill='#e74c3c', outline='black')
            self.canvas.create_text(x + cell_width/2, start_y - 25,
                                   text="CABEZAL", font=('Arial', 9, 'bold'), fill='#e74c3c')
        
    def show_result(self):
        if self.tm.is_accepted():
            self.result_label.config(text="BIEEEEN, CADENA ACEPTADA", fg="#00ff6a")
            messagebox.showinfo("Resultado", "la cadena fue ACEPTADA por la máquina de ayan")
        else:
            self.result_label.config(text="nOoOOO, CADENA RECHAZADA", fg="#ff1900")
            messagebox.showinfo("Resultado", "La cadena fue RECHAZADA por la máquina")
        
        self.step_button.config(state=tk.DISABLED)
        self.run_button.config(state=tk.DISABLED)


def main():
    root = tk.Tk()
    app = TuringSimulatorGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
